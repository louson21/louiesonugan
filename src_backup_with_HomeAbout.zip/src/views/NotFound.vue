<template>
    <div id="main">
        <h1>Not Found!</h1>
    </div>
</template>

<script>
export default {
    name: "NotFound"
}
</script>

<style>

</style>