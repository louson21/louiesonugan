<template>
  <div class="home">
    {{documentId}}
    <component
      v-for="(slice, index) in slices"
      :key="index"
      :is="slice.slice_type + 'module'"
      :slice="slice">
      </component>
  </div>
</template>

<script>

import textmodule from '@/components/slices/textmodule';
export default {
  name: 'Home',
  components: {
    textmodule
  },
  data () {
    return {
      documentId: "",
      slices: {

      }
    };
  },
  methods: {
    getContent() {
      this.$prismic.client.getByUID("page","homepage")
      .then((document) => {
        if (document) {
          this.documentId = document.id;
          this.slices = document.data.body;
        } else {
          this.$router.push({name: 'not-found'})
        }
      })
    }
  },
  created () {
    this.getContent()
  }
}
</script>
