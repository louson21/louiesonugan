<template>
  <div class="about">
    <component
      v-for="(slice, index) in slices"
      :key="index"
      :is="slice.slice_type + 'module'"
      :slice="slice">
      </component>
  </div>
</template>

<script>

import textmodule from '@/components/slices/textmodule';
export default {
  name: 'about',
  components: {
    textmodule
  },
  data () {
    return {
      documentId: "",
      slices: {

      }
    };
  },
  methods: {
    getContent() {
      this.$prismic.client.getByUID("page","about")
      .then((document) => {
        if (document) {
          this.slices = document.data.body;
        } else {
          this.$router.push({name: 'not-found'})
        }
      })
    }
  },
  created () {
    this.getContent()
  }
}
</script>
