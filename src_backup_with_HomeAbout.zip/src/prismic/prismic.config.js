const api = {
    apiEndpoint: "https://louiesonugan.prismic.io/api/v2",
}

module.exports = api